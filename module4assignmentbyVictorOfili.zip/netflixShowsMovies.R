# Load necessary library
library(readr)
install.packages("plotly")
library("plotly")
library("lattice")
library("ggplot2")

# Reading the Netflix_shows_movies. data file
data <- read_csv('Netflix_shows_movies..csv')

# Viewing the first few rows of the data
head(data, 10)

# Filtering for Movies and removing rows with missing duration or genre
movies <- subset(data, type == "Movie" & !is.na(duration) & !is.na(listed_in))

# Extracting numeric duration
movies$duration_num <- as.numeric(gsub(" min", "", movies$duration))

# Splitting genres
library(tidyr)
movies_genres <- separate_rows(movies, listed_in, sep = ",\\s*")

# Aggregating total duration by genre
genre_duration <- aggregate(duration_num ~ listed_in, data = movies_genres, sum, na.rm = TRUE)

# Getting top 10 genres by total duration
top_genres <- head(genre_duration[order(-genre_duration$duration_num), ], 10)

# Creating barchart using ggplot2
library(ggplot2)
ggplot(top_genres, aes(x = reorder(listed_in, duration_num), y = duration_num)) +
    geom_bar(stat = "identity", fill = "steelblue") +
    coord_flip() +
    labs(title = "Top 10 Most Watched Genres by Total Duration (Movies)",
             x = "Genre",
             y = "Total Duration (min)")





